from ctypes.wintypes import RGB
from dis import show_code
import cv2
import numpy as np
from skimage.transform import AffineTransform, SimilarityTransform, ProjectiveTransform, warp, rescale
from skimage.feature import (match_descriptors, ORB, plot_matches)
from skimage.color import rgb2gray
from skimage.measure import ransac

def get_matches(im_or, im_tf, n_keypoints=500,ax = None, title ='Original vs transformed'):
    """get_matches zoekt punten op 2 foto's die met elkaar gelinkt kunnen worden

    Args:
        im_or (_type_): originele image
        im_tf (_type_): getransformeerde image
        n_keypoints (int, optional): aantal match punten. Defaults to 500.
        ax (_type_, optional): subplot van plot. Defaults to None.
        title (str, optional): Titel van de te plotten image. Defaults to 'Original vs transformed'.

    Returns:
        _type_: _description_
    """
    descriptor_extractor = ORB(n_keypoints=n_keypoints)
    descriptor_extractor.detect_and_extract(rgb2gray(im_or))
    keyPoint_or = descriptor_extractor.keypoints
    descriptors_or = descriptor_extractor.descriptors
    descriptor_extractor.detect_and_extract(rgb2gray(im_tf))
    keypoints_tf = descriptor_extractor.keypoints
    descriptors_tf = descriptor_extractor.descriptors
    matches = match_descriptors(descriptors_or,descriptors_tf,cross_check=True)
    if ax is not None:
        plot_matches(ax,im_or,im_tf,keyPoint_or,keypoints_tf, matches)
        ax.axis('off')
        ax.set_title(title)
    return matches, keyPoint_or, keypoints_tf

def get_tf_model(src,dst, xTransform=AffineTransform, n_keypoints=500,min_samples=4,residual_threshold=2,**kwargs):
    """genereerd een transfer model aan de hand van gematchte punten.

    Args:
        src (_type_): source image
        dst (_type_): destination image
        xTransform (_type_, optional): Transformatie model die megegeven word met ransac (random sample consensus). Defaults to AffineTransform.
        n_keypoints (int, optional): aantal keypoints. Defaults to 500.
        min_samples (int, optional): mimum aantal samples. Defaults to 4.
        residual_threshold (int, optional): _description_. Defaults to 2.

    Returns:
        tf_model(_type_): Transfer model
    """
    matches,kp_src, kp_dst = get_matches(src,dst,n_keypoints=n_keypoints)
    src = kp_src[matches[:,0]][:,::-1]
    dst = kp_dst[matches[:,1]][:,::-1]
    tf_model, _ =ransac((src,dst),xTransform,min_samples=min_samples,residual_threshold=residual_threshold, **kwargs)
    return tf_model

def _get_stitch_images(im0,im1,tf_model=None,n_keypoints=500,min_samples=4,residual_threshold=2,**kwargs):
    """genereerd van 2 foto's de gestichted foto's en returnd het appart.

    Args:
        im0 (_type_): image 0
        im1 (_type_): image 1
        tf_model (_type_, optional): Transfer model. Defaults to None.
        n_keypoints (int, optional): aantal keypoints. Defaults to 500.
        min_samples (int, optional): min aantal samples. Defaults to 4.
        residual_threshold (int, optional): _description_. Defaults to 2.

    Returns:
        im0 (_type_): image 0
        im1 (_type_): image 1
    """
    if tf_model is None:                                    # gebruik similarityTransform als geen model is meegegeven
        tf_model = SimilarityTransform()                                
    elif tf_model == 'auto':                                # laat get_tf_model een model berekenen als auto als argument gegeven wordt
        tf_model = get_tf_model(im1,im0,xTransform=ProjectiveTransform,n_keypoints=n_keypoints,min_samples=min_samples,residual_threshold=residual_threshold, **kwargs)

    r,c = im0.shape[:2]                             
    corners0 = np.array([[0,0],[0,r],[c,0],[c,r]])          # hoeken van image0 
    r,c = im1.shape[:2]
    corners1 = np.array([[0,0],[0,r],[c,0],[c,r]])          # hoeken van image1
    wcorners1= tf_model(corners1)                           # hoeken van tf model 

    print("corners0: "+str(corners0))
    print("corners1: "+str(corners1))
    print("wcorners1: "+str(wcorners1))
    all_corners = np.vstack((corners0, corners1,wcorners1)) # stack alle hoeken samen
    min_corner = all_corners.min(axis=0)                    
    max_corner = all_corners.max(axis=0)
    new_shape = max_corner-min_corner                       # maak nieuwe shape zodat images er in passen
    new_shape = np.ceil(new_shape[::-1]).astype(np.int32)   
    shift = SimilarityTransform(translation=-min_corner)    # maak shift matrix aan zorgt ervoor dat alle coordinaten positief blijven
    im0_ = warp(im0,shift.inverse,output_shape=new_shape,cval=-1)               # geen transformatie gedaan hier. enkel vergroot of verklijd naar new_shape.
    im1_ = warp(im1,(tf_model+shift).inverse,output_shape=new_shape,cval=-1)    # transformatie volgens tf model. shift zodat coordinaten posetief blijven
    return im0_,im1_

def _merge_stich_images(im0_,im1_,mask_index=None,cval=0):
    """afstemmen van 2 foto's aan elkaar zodat ze verder verwerkt kunnen worden.

    Args:
        im0_ (_type_): image 0
        im1_ (_type_): image 1
        mask_index (_type_, optional): geeft aan welke afbeelding als achtergrond diend. Defaults to None.
        cval (int, optional): set pixls corresponding to background.. Defaults to 0.

    Returns:
        _type_: _description_
    """
    if mask_index is not None:                                          # zet volgens mask index pixels achter de src_im op zwart om beter te kunnen optellen
        if mask_index==0:           
            im1_[im0_>-1] = 0           
        elif mask_index ==1:            
            im0_[im1_>-1] = 0           
    else:                                                               # als geen masker gegeven wordt, laat de 2 images samen smelten 
        alpha = 1.0*(im0_[:,:,0] !=-1)+1.0*(im1_[:,:,0]!=-1)            
    bgmask = -1*((im0_==-1)&(im1_==-1))                                 # background masker maken
    im0_[im0_==-1] = 0                                                  # zet de achtergronden van im0 en 1 op 0
    im1_[im1_==-1] = 0  

    merged = im0_ + im1_                                                # nerge de 2 img
    if mask_index is None: merged /= np.maximum(alpha,1)[...,None]      #als geen masker: herschaal de intensiteit van de pixels waar de 2 foto's op komen te staan
    merged[bgmask==-1]=cval
    return merged                               

def _stitch(im0,im1, mask_idx=None,cval=0,show=True,tf_model=None,n_keypoints=500,min_samples=4,residual_threshold=2,**kwargs):
    """"samenvoeging van _get_stitch_images & _merge_stich_images.  via Show kan de afbeelding getoond worden.

    Args:
        im0 (_type_): image 0
        im1 (_type_): image 1
        mask_idx (_type_, optional): geeft aan welke afbeelding als achtergrond diend. Defaults to None.
        cval (int, optional): set pixls corresponding to background. Defaults to 0.
        show (bool, optional): display image or not. Defaults to True.
        tf_model (_type_, optional): Transfer model. Defaults to None.
        n_keypoints (int, optional): aantal keypoints. Defaults to 500.
        min_samples (int, optional): minimum aantal samples. Defaults to 4.
        residual_threshold (int, optional): _description_. Defaults to 2.

    Returns:
        merged (_type_): geeft gestichd beeld terug
    """

    im0_,im1_ = _get_stitch_images(im0,im1,tf_model=tf_model,n_keypoints=n_keypoints,min_samples=min_samples,residual_threshold=residual_threshold,**kwargs)
    merged = _merge_stich_images(im0_=im0_,im1_=im1_,mask_index=mask_idx,cval=cval)
    if (show):
        cv2.imshow('merged_image',merged)
    else:
        return merged

def stiche(ims,order=[1,0,2],mask_idx=None,tf_model='auto',n_keypoints=1000,min_samples=4,residual_threshold=2,**kwargs):
    """plakt meerder afbeeldingen samen

    Args:
        ims (_type_): Array van verschillende afbeeldingen
        order (list, optional): volgorde waarin ze gestiched moeten worden. Defaults to [1,0,2].
        mask_idx (_type_, optional): geeft aan welke afbeelding als achtergrond diend. Defaults to None.
        tf_model (str, optional): Transfer model. Defaults to 'auto'.
        n_keypoints (int, optional): aantal keypoints. Defaults to 1000.
        min_samples (int, optional): minimum aantal samples. Defaults to 4.
        residual_threshold (int, optional): _description_. Defaults to 2.

    Returns:
        mergedim(_type_): geeft de voledige gestichte afbeelding terug
    """
    ims_sorted=[None]*len(ims)                          # 
    cval_val=-1
    #reorder images
    for x in range(len(ims)):                           # herorder ima volgens order parameter
        ims_sorted[order[x]] =ims[x]

    mergedim = ims_sorted[0]                            # steek eerste foto in mergedim
    #merge sorted images
    for x in range(len(ims_sorted)-1):                  # zolang niet de laatste foto wordt gemergd geen show
        show_Val = False                                        
        if(x==len(ims_sorted)-2):
            cval_val=0
            show_Val = True                             # de reeks foto's worden 1 voor 1 gestitchd via _stitch. na laatste foto wordt mergedim getoond via de _stitch methode      
        mergedim = _stitch(mergedim,ims_sorted[x+1],tf_model=tf_model,n_keypoints=n_keypoints,min_samples=min_samples,residual_threshold=residual_threshold,cval=cval_val,show=show_Val)
        
    return mergedim



files=['DFM_4209.jpg','DFM_4210.jpg','DFM_4211.jpg']
ims = []
for i,file in enumerate(files):
    im = cv2.imread('./imgs/'+file,cv2.IMREAD_ANYCOLOR)                 # inlezen van alle foto's
    im = im[:,500:500+1987,:]                                           # foto bijsnijden voor beter stiching
    ims.append(rescale(im,0.25,anti_aliasing=True,multichannel=True))   # elke foto toegevoegd aan ims array

sorted_ims = stiche(ims,order=[1,0,2])                                  # foto's worden gestiched in andere volgorde voor een beter resultaat, probeer maar eens in ander volgorde
cv2.waitKey(100000)
